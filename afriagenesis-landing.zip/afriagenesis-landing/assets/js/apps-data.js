// Données d'exemple pour le App Store Afriagenesis
window.AFRIAGENESIS_APPS = [
  {
    name: "M-Pesa Connect Africa",
    category: "Fintech",
    country: "Kenya / Afrique de l'Est",
    description: "Paiements mobiles, transferts rapides, intégration marchands pour l'Afrique de l'Est.",
    tags: ["Mobile Money", "Retail", "API"],
    monthlyActiveUsers: "5M+"
  },
  {
    name: "Wave Panafrica",
    category: "Paiements",
    country: "UEMOA",
    description: "Super-app de paiement à faible coût, adaptée aux économies de la zone franc.",
    tags: ["Paiement", "UEMOA", "Wallet"],
    monthlyActiveUsers: "3M+"
  },
  {
    name: "EDUA Classroom",
    category: "Éducation",
    country: "Afrique de l'Ouest",
    description: "Plateforme d'apprentissage pour écoles, universités et formations professionnelles.",
    tags: ["LMS", "Certification", "Jeunesse"],
    monthlyActiveUsers: "1.2M+"
  },
  {
    name: "AgriSense Sahel",
    category: "Agritech",
    country: "Sahel",
    description: "Outils pour coopératives agricoles : données météo, prix, financement et assurance.",
    tags: ["Agriculture", "Data", "Financement"],
    monthlyActiveUsers: "800K+"
  },
  {
    name: "CarePlus Telemed",
    category: "Santé",
    country: "Multi-pays",
    description: "Téléconsultation, gestion de dossiers médicaux, intégration avec assurances locales.",
    tags: ["Santé", "Télémedecine", "Assurance"],
    monthlyActiveUsers: "900K+"
  },
  {
    name: "CityMove Mobility",
    category: "Mobilité",
    country: "Villes africaines",
    description: "Gestion intelligente de flottes, taxis, bus et mobilité douce pour les villes africaines.",
    tags: ["Transport", "Smart City", "Data"],
    monthlyActiveUsers: "650K+"
  }
];
