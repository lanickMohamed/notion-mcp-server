document.addEventListener("DOMContentLoaded", () => {
  const appsContainer = document.getElementById("apps-container");
  const apps = window.AFRIAGENESIS_APPS || [];

  apps.forEach((app) => {
    const card = document.createElement("article");
    card.className = "app-card hover-lift";
    card.innerHTML = `
      <div class="app-meta">
        <span>${app.category}</span>
        <span>${app.country}</span>
      </div>
      <h3 class="app-title">${app.name}</h3>
      <p class="app-desc">${app.description}</p>
      <div class="app-tags">
        ${app.tags
          .map((t) => `<span class="app-tag">${t}</span>`)
          .join("")}
      </div>
      <div class="app-meta" style="margin-top:0.5rem;">
        <span>MAU</span>
        <span>${app.monthlyActiveUsers}</span>
      </div>
    `;
    appsContainer.appendChild(card);
  });

  const defaultLang = "fr";
  window.AFRIAGENESIS_LANG.setLanguage(defaultLang);

  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      window.AFRIAGENESIS_LANG.setLanguage(lang);
    });
  });

  const form = document.querySelector(".contact-form");
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Votre demande a bien été enregistrée (démo front uniquement).");
      form.reset();
    });
  }
});
