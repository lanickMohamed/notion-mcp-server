// Dictionnaire simple FR / EN pour la landing Afriagenesis
const I18N = {
  fr: {
    hero_title: "La marketplace souveraine des applications africaines",
    hero_subtitle: "Découvrez, distribuez et monétisez les meilleures apps conçues pour l’Afrique, avec une infrastructure cloud souveraine et sécurisée.",
    cta_explore_apps: "Explorer les Apps",
    cta_become_dev: "Devenir développeur",
    badge_souverainete: "Souveraineté numérique africaine",
    badge_multilingue: "Multi-langue & multi-pays",
    badge_cloud: "Cloud distribué Afriagenesis",
    hero_card_title: "Store temps réel",
    hero_card_subtitle: "Statistiques, téléchargements, paiements locaux, tout est piloté par GENESIS v3.12.1.",
    metric_apps: "Apps actives",
    metric_countries: "Pays couverts",
    metric_latency: "Latence moyenne",

    features_title: "Pensé pour l’Afrique, calibré pour le monde",
    features_subtitle: "Architecturé avec GENESIS v3.12.1, TRM et les modules S7, S8, S9, S10, S12 et S14.",
    feature_security_title: "Sécurité & conformité",
    feature_security_desc: "Module S7 (sécurité) et S8 (conformité) : audit des apps, contrôle des permissions, traçabilité complète des déploiements.",
    feature_multilang_title: "Multi-langue & local",
    feature_multilang_desc: "Swahili, Peulh, Wolof, Fon, Yoruba, Arabe, Français, Anglais, et plus encore, avec pricing adapté à chaque zone monétaire.",
    feature_api_title: "Dev Store & APIs",
    feature_api_desc: "Tableau de bord développeur, clés API, sandbox, webhooks, intégration Mobile Money, cartes et paiements régionaux.",
    feature_cloud_title: "Cloud souverain distribué",
    feature_cloud_desc: "Nœuds cloud situés en Afrique, optimisés GENESIS, intégrables à des clouds publics ou privés.",

    apps_title: "App Store – Sélection Africa First",
    apps_subtitle: "Une sélection d’applications vérifiées, classées par secteur (fintech, santé, éducation, agritech, culture…).",

    dev_title: "Dev Store – Monétisez vos solutions",
    dev_subtitle: "Publiez vos apps, définissez vos plans, connectez vos paiements locaux et laissez GENESIS gérer le reste.",
    dev_benefit_1: "Console développeur unifiée (web & mobile)",
    dev_benefit_2: "Analytics temps réel (téléchargements, rétention, revenus)",
    dev_benefit_3: "Intégration Mobile Money, cartes, wallets panafricains",
    dev_benefit_4: "Validation et certification Afriagenesis (qualité & sécurité)",
    dev_cta: "Ouvrir un compte développeur",

    admin_preview_title: "Aperçu console Admin",
    admin_metric_1: "Temps réel : connexions simultanées",
    admin_metric_2: "Revenus 30 derniers jours",
    admin_metric_3: "Apps en revue S7",
    admin_note: "Cette console est pilotée par GENESIS v3.12.1 et connectable à votre SI existant.",

    how_title: "Comment Afriagenesis App Store fonctionne",
    how_step1_title: "Onboarding & cadrage",
    how_step1_desc: "Diagnostic GENESIS (DFM + TRM), définition des pays, monnaies, langues, et des règles de gouvernance (S7, S8, S14).",
    how_step2_title: "Publication & certification",
    how_step2_desc: "Les développeurs publient leurs apps, le store vérifie sécurité, conformité, performance et qualité d’intégration.",
    how_step3_title: "Distribution & monétisation",
    how_step3_desc: "Les utilisateurs finaux accèdent aux apps via web, mobile ou canaux intégrés. Paiements et reporting automatisés.",

    contact_title: "Parler avec Afriagenesis",
    contact_subtitle: "Ministère, régulateur, opérateur, banque, fintech ou scale-up ? Construisons votre App Store souverain.",
    contact_type_1: "Intégration pays / opérateurs",
    contact_type_2: "Store sectoriel (banque, éducation, santé…)",
    contact_type_3: "Programmes développeurs & écosystèmes",

    form_name: "Nom complet",
    form_email: "Email professionnel",
    form_type: "Type d’organisation",
    form_message: "Votre projet / besoin",
    form_opt_state: "État / Ministère",
    form_opt_bank: "Banque / Institution financière",
    form_opt_telco: "Opérateur télécom",
    form_opt_startup: "Startup / Scale-up",
    form_opt_other: "Autre",
    form_submit: "Demander une présentation",

    footer_slogan: "Souveraineté numérique africaine, par design."
  },
  en: {
    hero_title: "The sovereign marketplace for African applications",
    hero_subtitle: "Discover, distribute and monetise apps designed for Africa, powered by a secure sovereign cloud.",
    cta_explore_apps: "Browse Apps",
    cta_become_dev: "Become a Developer",
    badge_souverainete: "African digital sovereignty",
    badge_multilingue: "Multi-language & multi-country",
    badge_cloud: "Distributed Afriagenesis Cloud",
    hero_card_title: "Real-time Store",
    hero_card_subtitle: "Stats, downloads, local payments – all orchestrated by GENESIS v3.12.1.",
    metric_apps: "Active apps",
    metric_countries: "Covered countries",
    metric_latency: "Average latency",

    features_title: "Built for Africa, calibrated for the world",
    features_subtitle: "Architected with GENESIS v3.12.1, TRM and modules S7, S8, S9, S10, S12 and S14.",
    feature_security_title: "Security & compliance",
    feature_security_desc: "S7 (security) and S8 (compliance): app audits, permission controls and full deployment traceability.",
    feature_multilang_title: "Multi-language & local focus",
    feature_multilang_desc: "Swahili, Peulh, Wolof, Fon, Yoruba, Arabic, French, English and more, with pricing adapted to each region.",
    feature_api_title: "Dev Store & APIs",
    feature_api_desc: "Developer console, API keys, sandbox, webhooks, Mobile Money and card integrations.",
    feature_cloud_title: "Distributed sovereign cloud",
    feature_cloud_desc: "Cloud nodes based in Africa, GENESIS-optimised and integrable with public or private clouds.",

    apps_title: "App Store – Africa First selection",
    apps_subtitle: "A curated set of verified apps, organised by sector (fintech, health, education, agritech, culture…).",

    dev_title: "Dev Store – Monetise your solutions",
    dev_subtitle: "Publish your apps, define your plans, connect local payments and let GENESIS handle the rest.",
    dev_benefit_1: "Unified developer console (web & mobile)",
    dev_benefit_2: "Real-time analytics (downloads, retention, revenue)",
    dev_benefit_3: "Mobile Money, card and pan-African wallet integrations",
    dev_benefit_4: "Afriagenesis validation & certification (quality & security)",
    dev_cta: "Open a developer account",

    admin_preview_title: "Admin console preview",
    admin_metric_1: "Real-time concurrent sessions",
    admin_metric_2: "Last 30 days revenue",
    admin_metric_3: "Apps under S7 review",
    admin_note: "This console is powered by GENESIS v3.12.1 and can connect to your existing systems.",

    how_title: "How Afriagenesis App Store works",
    how_step1_title: "Onboarding & scoping",
    how_step1_desc: "GENESIS diagnostic (DFM + TRM), definition of countries, currencies, languages and governance rules (S7, S8, S14).",
    how_step2_title: "Publishing & certification",
    how_step2_desc: "Developers publish their apps; the store validates security, compliance, performance and integration quality.",
    how_step3_title: "Distribution & monetisation",
    how_step3_desc: "End-users access apps through web, mobile or integrated channels. Payments and reporting are automated.",

    contact_title: "Talk with Afriagenesis",
    contact_subtitle: "Ministry, regulator, operator, bank, fintech or scale-up? Let’s build your sovereign App Store.",
    contact_type_1: "Country / operator integration",
    contact_type_2: "Sector store (banking, education, health…)",
    contact_type_3: "Developer programmes & ecosystems",

    form_name: "Full name",
    form_email: "Business email",
    form_type: "Type of organisation",
    form_message: "Your project / needs",
    form_opt_state: "State / Ministry",
    form_opt_bank: "Bank / Financial institution",
    form_opt_telco: "Telecom operator",
    form_opt_startup: "Startup / Scale-up",
    form_opt_other: "Other",
    form_submit: "Request a presentation",

    footer_slogan: "African digital sovereignty, by design."
  }
};

function setLanguage(lang) {
  const dict = I18N[lang] || I18N.fr;
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (dict[key]) {
      el.textContent = dict[key];
    }
  });
  document.querySelectorAll(".lang-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
  });
  document.documentElement.lang = lang;
}

window.AFRIAGENESIS_LANG = {
  setLanguage
};
